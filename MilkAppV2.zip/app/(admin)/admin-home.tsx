import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, TextInput, Button, StyleSheet, Alert, ActivityIndicator, ScrollView, Dimensions
} from 'react-native';
import {
  collection, doc, getDoc, getDocs, setDoc, addDoc
} from 'firebase/firestore';
import { db } from '../../firebaseConfig';
import { useFocusEffect } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';

const todayStr = new Date().toISOString().split('T')[0];
const screenWidth = Dimensions.get('window').width;

export default function AdminHome() {
  const [loadedMilk, setLoadedMilk] = useState<number | null>(null);
  const [inputLiters, setInputLiters] = useState('');
  const [deliveredMilk, setDeliveredMilk] = useState(0);
  const [loading, setLoading] = useState(true);
  const [newCustomer, setNewCustomer] = useState({
    name: '',
    phone: '',
    address: '',
  });

  const addCustomer = async () => {
    const { name, phone, address } = newCustomer;
    if (!name || !phone || !address) {
      return Alert.alert('Please fill all fields');
    }

    try {
      await addDoc(collection(db, 'customers'), {
        name,
        phone,
        address,
        createdAt: new Date().toISOString(),
      });

      setNewCustomer({ name: '', phone: '', address: '' });
      Alert.alert('Success', 'Customer added');
    } catch (error) {
      Alert.alert('Error', 'Failed to add customer');
    }
  };

  const fetchStock = async () => {
    const stockRef = doc(db, 'adminStock', todayStr);
    const stockSnap = await getDoc(stockRef);
    if (stockSnap.exists()) {
      const data = stockSnap.data();
      setLoadedMilk(data.loadedLiters || 0);
    }
  };

  const calculateDelivered = async () => {
    const ordersRef = collection(db, 'dailyOrders');
    const ordersSnap = await getDocs(ordersRef);

    let total = 0;
    ordersSnap.forEach((doc) => {
      const data = doc.data();
      if (data.date === todayStr && data.status === 'Delivered') {
        total += data.quantity || 0;
      }
    });

    setDeliveredMilk(total);
  };

  useFocusEffect(
    useCallback(() => {
      const load = async () => {
        setLoading(true);
        await fetchStock();
        await calculateDelivered();
        setLoading(false);
      };
      load();
    }, [])
  );

  const handleSetStock = async () => {
    const amount = parseFloat(inputLiters);
    if (!amount || amount <= 0) {
      Alert.alert('Invalid input');
      return;
    }

    await setDoc(doc(db, 'adminStock', todayStr), {
      loadedLiters: amount,
      createdAt: new Date().toISOString(),
    });

    setLoadedMilk(amount);
    setInputLiters('');
    Alert.alert('Success', 'Milk stock set for today.');
  };

  if (loading) return <ActivityIndicator style={{ marginTop: 60 }} color="#fff" size="large" />;

  const remaining = loadedMilk !== null ? (loadedMilk - deliveredMilk).toFixed(2) : '--';

  return (
    <LinearGradient
      colors={['#0f0c29', '#302b63', '#24243e']}
      style={styles.background}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>📊 Admin Dashboard</Text>

        <View style={styles.card}>
          <Text style={styles.label}>📅 Date</Text>
          <Text style={styles.value}>{todayStr}</Text>

          <Text style={styles.label}>📦 Loaded Milk</Text>
          <Text style={styles.value}>{loadedMilk ?? '--'} L</Text>

          <Text style={styles.label}>🥛 Delivered Milk</Text>
          <Text style={styles.value}>{deliveredMilk} L</Text>

          <Text style={styles.label}>🚚 Remaining Milk</Text>
          <Text style={[styles.value, { color: '#facc15' }]}>{remaining} L</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>➕ Add New Customer</Text>
          <TextInput
            placeholder="Name"
            placeholderTextColor="#bbb"
            style={styles.input}
            value={newCustomer.name}
            onChangeText={(text) => setNewCustomer({ ...newCustomer, name: text })}
          />
          <TextInput
            placeholder="Phone"
            placeholderTextColor="#bbb"
            style={styles.input}
            keyboardType="phone-pad"
            value={newCustomer.phone}
            onChangeText={(text) => setNewCustomer({ ...newCustomer, phone: text })}
          />
          <TextInput
            placeholder="Address"
            placeholderTextColor="#bbb"
            style={styles.input}
            value={newCustomer.address}
            onChangeText={(text) => setNewCustomer({ ...newCustomer, address: text })}
          />
          <Button title="Add Customer" color="#10b981" onPress={addCustomer} />
        </View>

        {loadedMilk === null && (
          <View style={styles.card}>
            <TextInput
              placeholder="Set Milk Stock (L)"
              placeholderTextColor="#bbb"
              style={styles.input}
              keyboardType="numeric"
              value={inputLiters}
              onChangeText={setInputLiters}
            />
            <Button title="Set Today's Milk Stock" color="#3b82f6" onPress={handleSetStock} />
          </View>
        )}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    padding: 20,
  },
  title: {
    fontSize: 28,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 30,
    textAlign: 'center',
  },
  card: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderColor: '#ffffff20',
    borderWidth: 1,
  },
  label: {
    color: '#ccc',
    fontSize: 15,
    marginTop: 10,
  },
  value: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '600',
  },
  sectionTitle: {
    color: '#fff',
    fontSize: 18,
    marginBottom: 10,
    fontWeight: '600',
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    color: '#fff',
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
    fontSize: 16,
  },
});
