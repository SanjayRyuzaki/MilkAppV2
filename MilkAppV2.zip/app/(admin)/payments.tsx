import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, StyleSheet, ActivityIndicator, Dimensions
} from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../firebaseConfig';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';

const RATE_PER_LITER = 50;

export default function AdminPayments() {
  const [loading, setLoading] = useState(true);
  const [payments, setPayments] = useState<any[]>([]);

  const getCurrentMonthDates = () => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const end = new Date(now.getFullYear(), now.getMonth() + 1, 0).toISOString();
    return [start, end];
  };

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        setLoading(true);
        const customersSnap = await getDocs(collection(db, 'customers'));
        const ordersSnap = await getDocs(collection(db, 'dailyOrders'));

        const customersMap: { [id: string]: any } = {};
        customersSnap.forEach(doc => {
          customersMap[doc.id] = doc.data();
        });

        const [startOfMonth, endOfMonth] = getCurrentMonthDates();

        const customerTotals: { [id: string]: number } = {};

        ordersSnap.forEach(doc => {
          const data = doc.data();
          if (
            data.status === 'Delivered' &&
            data.date >= startOfMonth &&
            data.date <= endOfMonth
          ) {
            const id = data.customerId;
            customerTotals[id] = (customerTotals[id] || 0) + (data.quantity || 0);
          }
        });

        const paymentSummary = Object.entries(customerTotals).map(([id, liters]) => {
          const customer = customersMap[id];
          return {
            id,
            name: customer?.name || 'Unknown',
            phone: customer?.phone || '',
            liters,
            amount: liters * RATE_PER_LITER,
          };
        });

        setPayments(paymentSummary);
      } catch (error) {
        console.error('Failed to load payments:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPayments();
  }, []);

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#fff" />
      </View>
    );
  }

  return (
    <LinearGradient
      colors={['#0f0c29', '#302b63', '#24243e']}
      style={styles.background}
    >
      <View style={styles.container}>
        <Text style={styles.title}>💰 Monthly Payments</Text>
        <FlatList
          data={payments}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <BlurView intensity={30} tint="dark" style={styles.card}>
              <Text style={styles.name}>{item.name} ({item.phone})</Text>
              <Text style={styles.info}>🍼 Total Liters: {item.liters}</Text>
              <Text style={styles.info}>💵 Amount Due: ₹{item.amount}</Text>
            </BlurView>
          )}
        />
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#1c1c2b',
  },
  container: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 20,
    textAlign: 'center',
  },
  card: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    padding: 16,
    borderRadius: 16,
    marginBottom: 14,
    borderColor: '#ffffff20',
    borderWidth: 1,
  },
  name: {
    color: '#facc15',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 6,
  },
  info: {
    color: '#fff',
    fontSize: 14,
    marginBottom: 4,
  },
});
