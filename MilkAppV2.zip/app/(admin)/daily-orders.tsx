import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, Button, FlatList, StyleSheet,
  Alert, TouchableOpacity, ActivityIndicator, ScrollView
} from 'react-native';
import {
  collection, addDoc, getDocs, query, where
} from 'firebase/firestore';
import { db } from '../../firebaseConfig';
import { LinearGradient } from 'expo-linear-gradient';

export default function DailyOrders() {
  const [customerList, setCustomerList] = useState<any[]>([]);
  const [filteredCustomers, setFilteredCustomers] = useState<any[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [milkLiters, setMilkLiters] = useState('');
  const [note, setNote] = useState('');
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('Delivered');
  const [loading, setLoading] = useState(false);
  const [deliveredMap, setDeliveredMap] = useState<Record<string, number>>({});

  const todayStr = new Date().toISOString().split('T')[0];

  const fetchCustomers = async () => {
    try {
      const snapshot = await getDocs(collection(db, 'customers'));
      const customers = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      }));
      setCustomerList(customers);
      setFilteredCustomers(customers);
    } catch (error) {
      Alert.alert('Error fetching customers');
    }
  };

  const fetchTodayDeliveries = async () => {
    const q = query(collection(db, 'dailyOrders'));
    const snapshot = await getDocs(q);

    const map: Record<string, number> = {};
    snapshot.docs.forEach(doc => {
      const data = doc.data();
      if (data.date === todayStr && data.status === 'Delivered') {
        const cid = data.customerId;
        map[cid] = (map[cid] || 0) + (data.quantity || 0);
      }
    });

    setDeliveredMap(map);
  };

  useEffect(() => {
    (async () => {
      await fetchCustomers();
      await fetchTodayDeliveries();
    })();
  }, []);

  const handleSearch = (text: string) => {
    setSearch(text);
    const filtered = customerList.filter(c =>
      (c.name && c.name.toLowerCase().includes(text.toLowerCase())) ||
      (c.phone && c.phone.includes(text))
    );
    setFilteredCustomers(filtered);
  };

  const checkDuplicate = async () => {
    const q = query(
      collection(db, 'dailyOrders'),
      where('customerId', '==', selectedCustomerId),
      where('date', '==', todayStr)
    );
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  };

  const submitMilkEntry = async () => {
    if (!selectedCustomerId || (!milkLiters && status === 'Delivered')) {
      return Alert.alert('Missing fields', 'Select customer and enter liters');
    }

    const litersNum = parseFloat(milkLiters);
    if (status === 'Delivered' && (isNaN(litersNum) || litersNum <= 0)) {
      return Alert.alert('Invalid Liters', 'Must be a positive number');
    }

    try {
      setLoading(true);

      const exists = await checkDuplicate();
      if (exists) {
        setLoading(false);
        return Alert.alert('Duplicate Entry', 'Milk already logged for today');
      }

      await addDoc(collection(db, 'dailyOrders'), {
        customerId: selectedCustomerId,
        quantity: status === 'Delivered' ? litersNum : 0,
        note,
        status,
        date: todayStr,
      });

      setMilkLiters('');
      setNote('');
      setSelectedCustomerId('');
      setSearch('');
      setStatus('Delivered');
      setFilteredCustomers(customerList);

      await fetchTodayDeliveries();

      Alert.alert('Success', 'Milk entry added');
    } catch (error) {
      Alert.alert('Error', 'Failed to add milk entry');
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient colors={['#0f0c29', '#302b63', '#24243e']} style={styles.background}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>🥛 Daily Milk Delivery</Text>

        <TextInput
          placeholder="Search customer"
          placeholderTextColor="#bbb"
          value={search}
          onChangeText={handleSearch}
          style={styles.input}
        />

        <FlatList
          data={filteredCustomers}
          keyExtractor={item => item.id}
          style={{ maxHeight: 200, marginBottom: 10 }}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[
                styles.customerItem,
                selectedCustomerId === item.id && styles.selectedItem,
              ]}
              onPress={() => setSelectedCustomerId(item.id)}
            >
              <Text style={{ color: '#fff' }}>
                {item.name} ({item.phone}) - {deliveredMap[item.id] || 0} L
              </Text>
            </TouchableOpacity>
          )}
        />

        <TextInput
          placeholder="Liters Delivered"
          placeholderTextColor="#bbb"
          value={milkLiters}
          onChangeText={setMilkLiters}
          keyboardType="numeric"
          style={styles.input}
          editable={status === 'Delivered'}
        />
        <TextInput
          placeholder="Note (optional)"
          placeholderTextColor="#bbb"
          value={note}
          onChangeText={setNote}
          style={styles.input}
        />

        <View style={styles.statusContainer}>
          {['Delivered', 'Skipped', 'Paused'].map((opt) => (
            <TouchableOpacity
              key={opt}
              onPress={() => setStatus(opt)}
              style={[
                styles.statusButton,
                status === opt && styles.activeStatus,
              ]}
            >
              <Text style={styles.statusText}>{opt}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Button
          title={loading ? 'Submitting...' : 'Submit Milk Entry'}
          onPress={submitMilkEntry}
          color="#10b981"
          disabled={loading}
        />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    color: '#fff',
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
    fontSize: 16,
  },
  customerItem: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 6,
    borderColor: '#fff3',
    borderWidth: 1,
  },
  selectedItem: {
    backgroundColor: '#3b82f6',
    borderColor: '#fff',
  },
  statusContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  statusButton: {
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#bbb',
    flex: 1,
    marginHorizontal: 5,
  },
  activeStatus: {
    backgroundColor: '#10b981',
    borderColor: '#fff',
  },
  statusText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: '600',
  },
});
