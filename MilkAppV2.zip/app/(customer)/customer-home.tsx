import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { db } from '../../firebaseConfig';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { Calendar, DateData } from 'react-native-calendars';
import { LinearGradient } from 'expo-linear-gradient';

export default function CustomerHome() {
  const { name, id } = useLocalSearchParams<{ name: string; id: string }>();
  const [logs, setLogs] = useState<any[]>([]);
  const [markedDates, setMarkedDates] = useState({});
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState('');
  const [totalLiters, setTotalLiters] = useState(0);

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const q = query(
          collection(db, 'dailyOrders'),
          where('customerId', '==', id),
          where('status', '==', 'Delivered')
        );
        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(doc => doc.data());

        const total = data.reduce((sum, item) => sum + (item.quantity || 0), 0);
        setTotalLiters(total);
        setLogs(data);

        const dateMap: Record<string, any> = {};
        data.forEach(entry => {
          const dateStr = entry.date?.split('T')[0];
          if (dateStr) {
            dateMap[dateStr] = {
              marked: true,
              dotColor: '#10b981',
              customStyles: {
                container: { backgroundColor: '#1e3a8a' },
                text: { color: '#fff', fontWeight: 'bold' },
              },
            };
          }
        });

        setMarkedDates(dateMap);
      } catch (err) {
        console.error('Error fetching milk logs:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchLogs();
  }, [id]);

  const handleDayPress = (day: DateData) => {
    setSelectedDate(day.dateString);
  };

  const selectedLogs = logs.filter(l => l.date?.startsWith(selectedDate));

  if (loading) return <ActivityIndicator style={{ marginTop: 40 }} color="#10b981" />;

  return (
    <LinearGradient colors={['#0f0c29', '#302b63', '#24243e']} style={styles.container}>
      <Text style={styles.title}>👋 Welcome, {name}!</Text>
      <Text style={styles.subtitle}>Total Liters Delivered: {totalLiters.toFixed(2)} L</Text>

      <Calendar
        markingType="custom"
        markedDates={{
          ...markedDates,
          [selectedDate]: {
            ...markedDates[selectedDate],
            selected: true,
            selectedColor: '#10b981',
          },
        }}
        onDayPress={handleDayPress}
        theme={{
          calendarBackground: 'transparent',
          dayTextColor: '#fff',
          monthTextColor: '#facc15',
          arrowColor: '#10b981',
          textDisabledColor: '#888',
        }}
        style={{ marginTop: 20, marginBottom: 20, borderRadius: 10 }}
      />

      {selectedDate ? (
        <View>
          <Text style={styles.subTitle}>📅 {selectedDate}</Text>
          {selectedLogs.length > 0 ? (
            selectedLogs.map((log, index) => (
              <View key={index} style={styles.card}>
                <Text style={styles.cardText}>🍼 Liters: {log.quantity}</Text>
                {log.note ? <Text style={styles.cardText}>📝 Note: {log.note}</Text> : null}
              </View>
            ))
          ) : (
            <Text style={styles.noLog}>No delivery logged.</Text>
          )}
        </View>
      ) : (
        <Text style={styles.noLog}>Select a date to view details</Text>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    color: '#facc15',
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#ccc',
    textAlign: 'center',
    marginBottom: 10,
  },
  subTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 10,
  },
  card: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    padding: 16,
    borderRadius: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#ffffff22',
  },
  cardText: {
    color: '#eee',
    fontSize: 15,
  },
  noLog: {
    color: '#aaa',
    fontSize: 14,
    textAlign: 'center',
  },
});
