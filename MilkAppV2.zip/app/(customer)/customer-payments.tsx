import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { db } from '../../firebaseConfig';
import { collection, getDocs, query, where } from 'firebase/firestore';

const RATE_PER_LITER = 50;

export default function CustomerPayments() {
  const [id, setId] = useState<string | null>(null);
  const [name, setName] = useState<string | null>(null);
  const [totalLiters, setTotalLiters] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadCustomerAndFetchLogs = async () => {
      try {
        const stored = await AsyncStorage.getItem('customer-info');
        if (!stored) {
          console.warn('No customer info found');
          return;
        }

        const { id, name } = JSON.parse(stored);
        setId(id);
        setName(name);

        const q = query(
          collection(db, 'dailyOrders'),
          where('customerId', '==', id),
          where('status', '==', 'Delivered')
        );

        const snapshot = await getDocs(q);
        const data = snapshot.docs.map(doc => doc.data());
        const total = data.reduce((sum, item) => sum + (item.quantity || 0), 0);
        setTotalLiters(total);
      } catch (err) {
        console.error('Error loading payment data:', err);
      } finally {
        setLoading(false);
      }
    };

    loadCustomerAndFetchLogs();
  }, []);

  const totalDue = (totalLiters * RATE_PER_LITER).toFixed(2);

  if (loading || !id) return <ActivityIndicator style={{ marginTop: 60 }} size="large" color="#10b981" />;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>💳 Payment Summary</Text>
      <Text style={styles.subtitle}>Hello, <Text style={styles.highlight}>{name}</Text></Text>

      <View style={styles.card}>
        <Text style={styles.label}>🍼 Total Milk Delivered</Text>
        <Text style={styles.value}>{totalLiters.toFixed(2)} L</Text>

        <Text style={styles.label}>💸 Rate per Liter</Text>
        <Text style={styles.value}>₹{RATE_PER_LITER}</Text>

        <Text style={styles.label}>💰 Amount Due</Text>
        <Text style={styles.due}>₹{totalDue}</Text>
      </View>

      <Text style={styles.footer}>* This is your total payment based on all delivered milk.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
    padding: 20,
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#facc15',
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    color: '#94a3b8',
    marginBottom: 25,
    textAlign: 'center',
  },
  highlight: {
    fontWeight: '600',
    color: '#10b981',
  },
  card: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 14,
    padding: 20,
    borderColor: '#334155',
    borderWidth: 1,
  },
  label: {
    fontSize: 15,
    color: '#cbd5e1',
    marginTop: 16,
  },
  value: {
    fontSize: 20,
    fontWeight: '500',
    color: '#f1f5f9',
  },
  due: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#10b981',
    marginTop: 10,
  },
  footer: {
    marginTop: 30,
    fontSize: 12,
    color: '#64748b',
    textAlign: 'center',
  },
});
