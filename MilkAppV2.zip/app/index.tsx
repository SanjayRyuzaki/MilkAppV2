import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import LottieView from 'lottie-react-native';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <LottieView
        source={require('../assets/animations/milk-bg.json')} // 🧊 Add your animation file here
        autoPlay
        loop
        style={styles.background}
      />

      <View style={styles.overlay}>
        <Text style={styles.title}> Welcome to Milk App</Text>

        <TouchableOpacity
          style={styles.button}
          onPress={() => router.push('/auth/admin-login')}
        >
          <Text style={styles.buttonText}>Login as Admin</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#10b981' }]}
          onPress={() => router.push('/auth/customer-login')}
        >
          <Text style={styles.buttonText}>Login as Customer</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  background: {
    position: 'absolute',
    width: width,
    height: '100%',
  },
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
    backgroundColor: 'rgba(0,0,0,0.1)',
  },
  title: {
    fontSize: 30,
    color: '#fff',
    fontWeight: 'bold',
    marginBottom: 40,
    textAlign: 'center',
  },
button: {
  backgroundColor: '#ffffffaa', // semi-transparent white
  paddingVertical: 14,
  paddingHorizontal: 30,
  borderRadius: 30,
  marginVertical: 10,
  width: '100%',
  borderWidth: 1,
  borderColor: '#ffffff33',
  shadowColor: '#000',
  shadowOpacity: 0.15,
  shadowOffset: { width: 0, height: 4 },
  shadowRadius: 8,
  elevation: 3,
},

buttonText: {
  color: '#111',
  fontSize: 16,
  fontWeight: '600',
  textAlign: 'center',
},
});
