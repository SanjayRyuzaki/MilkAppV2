import React, { useState } from 'react';
import { View, TextInput, Button, Alert, Text } from 'react-native';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../../firebaseConfig';
import { Picker } from '@react-native-picker/picker';

export default function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'admin' | 'customer'>('customer');

  const handleRegister = async () => {
    try {
      const userCred = await createUserWithEmailAndPassword(auth, email, password);
      const uid = userCred.user.uid;

      await setDoc(doc(db, 'users', uid), {
        email,
        role,
      });

      Alert.alert('Success', `User registered as ${role}`);
    } catch (err) {
      const error = err as Error;
      Alert.alert('Register Error', error.message);
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <Text>Register New User</Text>
      <TextInput placeholder="Email" value={email} onChangeText={setEmail} autoCapitalize="none" />
      <TextInput placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry />

      <Picker selectedValue={role} onValueChange={(value) => setRole(value)}>
        <Picker.Item label="Customer" value="customer" />
        <Picker.Item label="Admin" value="admin" />
      </Picker>

      <Button title="Register" onPress={handleRegister} />
    </View>
  );
}
