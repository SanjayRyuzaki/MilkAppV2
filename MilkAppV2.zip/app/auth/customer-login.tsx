import React, { useState } from 'react';
import {
  View, Text, TextInput, Alert, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform
} from 'react-native';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { db } from '../../firebaseConfig';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';

export default function CustomerLogin() {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleLogin = async () => {
    try {
      const customersRef = collection(db, 'customers');
      const q = query(customersRef, where('phone', '==', phone));
      const querySnapshot = await getDocs(q);

      if (querySnapshot.empty) {
        Alert.alert('Login Failed', 'Customer not found');
        return;
      }

      const doc = querySnapshot.docs[0];
      const docData = doc.data();

      if (password !== phone) {
        Alert.alert('Login Failed', 'Incorrect password');
        return;
      }

      const customerName = docData.name || 'Customer';
      const customerId = doc.id;

      await AsyncStorage.setItem('customer-info', JSON.stringify({
        id: customerId,
        name: customerName,
      }));

      router.replace({
        pathname: '/(customer)/customer-home',
        params: { name: customerName, id: customerId },
      });

    } catch (error) {
      Alert.alert('Error', (error as Error).message);
    }
  };

  return (
    <LinearGradient colors={['#141e30', '#243b55']} style={{ flex: 1 }}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={styles.container}
      >
        <BlurView intensity={70} tint="dark" style={styles.card}>
          <Text style={styles.title}>🧑‍🌾 Customer Login</Text>

          <TextInput
            placeholder="📱 Phone Number"
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
            placeholderTextColor="#aaa"
            style={styles.input}
          />
          <TextInput
            placeholder="🔐 Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            placeholderTextColor="#aaa"
            style={styles.input}
          />

          <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
            <Text style={styles.loginText}>Login</Text>
          </TouchableOpacity>
        </BlurView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 24,
  },
  card: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 20,
    padding: 25,
    borderWidth: 1,
    borderColor: '#ffffff20',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 12,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#facc15',
    textAlign: 'center',
    marginBottom: 25,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    color: '#fff',
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#ffffff30',
  },
  loginButton: {
    backgroundColor: '#10b981',
    paddingVertical: 14,
    borderRadius: 10,
    marginTop: 8,
  },
  loginText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
});
