/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(admin)` | `/(admin)/admin-home` | `/(admin)/daily-orders` | `/(admin)/payments` | `/(customer)` | `/(customer)/customer-home` | `/(customer)/customer-payments` | `/_sitemap` | `/admin-home` | `/auth/admin-login` | `/auth/customer-login` | `/auth/register` | `/customer-home` | `/customer-payments` | `/daily-orders` | `/payments`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
